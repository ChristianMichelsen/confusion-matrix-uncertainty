from .main import app

app(prog_name="confusion-matrix-uncertainty")
